SHOPIFY PRODUCT IMAGE MANAGER

1. Double-click start.bat.
2. The first launch installs the required app files automatically.
3. Your browser opens to http://localhost:3100.
4. Keep the black launcher window open while using the app.

Enter your myshopify.com domain, Client ID, and Client Secret from the Shopify
Dev Dashboard. The secret stays only in the local server's memory and clears
when the app closes. The app loads live products and can upload assigned images.
