@echo off
setlocal
cd /d "%~dp0"

echo ========================================
echo   Shopify Product Image Manager
echo ========================================
echo.

where node.exe >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js is not installed or is not available.
    echo Install the LTS version from https://nodejs.org/ and try again.
    goto :failed
)

where npm.cmd >nul 2>&1
if errorlevel 1 (
    echo ERROR: npm was not found. Reinstall the Node.js LTS version.
    goto :failed
)

if not exist "package.json" (
    echo ERROR: package.json is missing from %CD%
    echo Keep start.bat beside package.json in the app folder.
    goto :failed
)

set "NEED_INSTALL=0"
if not exist "node_modules\" set "NEED_INSTALL=1"
if not exist "node_modules\express\package.json" set "NEED_INSTALL=1"
if not exist "node_modules\multer\package.json" set "NEED_INSTALL=1"
if not exist "node_modules\vite\package.json" set "NEED_INSTALL=1"

if "%NEED_INSTALL%"=="1" (
    echo Installing or updating the app's required packages...
    echo This may take a few minutes.
    call npm.cmd install
    if errorlevel 1 goto :install_failed
)

echo.
echo Starting the app at http://localhost:3100
echo Keep this window open while using the app.
echo.
start "" /b powershell.exe -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 4; Start-Process 'http://localhost:3100'"
call npm.cmd run dev
if errorlevel 1 goto :run_failed
exit /b 0

:install_failed
echo.
echo ERROR: The app could not be installed. Review the message above.
goto :failed

:run_failed
echo.
echo ERROR: The app stopped unexpectedly. Review the message above.

:failed
echo.
pause
exit /b 1
