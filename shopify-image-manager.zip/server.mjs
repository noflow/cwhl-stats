import express from "express";
import multer from "multer";
import { createServer as createViteServer } from "vite";

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024, files: 50 } });
let connection = null;
app.use(express.json({ limit: "1mb" }));
app.get("/api/health", (_req, res) => res.json({ ok: true, service: "shopify-image-manager" }));

const cleanShop = (value = "") => value.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/$/, "");

async function getToken(shop, clientId, clientSecret) {
  const response = await fetch(`https://${shop}/admin/oauth/access_token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "client_credentials", client_id: clientId, client_secret: clientSecret }),
  });
  const data = await response.json();
  if (!response.ok || !data.access_token) throw new Error(data.error_description || data.error || "Shopify rejected the credentials.");
  return { value: data.access_token, expiresAt: Date.now() + ((data.expires_in || 86399) - 300) * 1000 };
}

async function token() {
  if (!connection) throw new Error("Connect to Shopify first.");
  if (!connection.token || Date.now() >= connection.token.expiresAt) connection.token = await getToken(connection.shop, connection.clientId, connection.clientSecret);
  return connection.token.value;
}

async function graphql(query, variables = {}) {
  const response = await fetch(`https://${connection.shop}/admin/api/2026-07/graphql.json`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Shopify-Access-Token": await token() },
    body: JSON.stringify({ query, variables }),
  });
  const json = await response.json();
  if (!response.ok || json.errors) throw new Error(json.errors?.map((error) => error.message).join("; ") || `Shopify request failed (${response.status}).`);
  return json.data;
}

app.post("/api/connect", async (req, res) => {
  try {
    const shop = cleanShop(req.body.shop);
    if (!shop.endsWith(".myshopify.com")) throw new Error("Use your store's .myshopify.com domain.");
    if (!req.body.clientId || !req.body.clientSecret) throw new Error("Client ID and Client Secret are required.");
    const next = { shop, clientId: req.body.clientId.trim(), clientSecret: req.body.clientSecret.trim(), token: null };
    next.token = await getToken(next.shop, next.clientId, next.clientSecret);
    connection = next;
    res.json({ ok: true, shop });
  } catch (error) { res.status(400).json({ error: error.message }); }
});

app.get("/api/products", async (_req, res) => {
  try {
    const data = await graphql(`query Products { products(first: 100, sortKey: TITLE) { nodes { id title variants(first: 100) { nodes { sku } } } } }`);
    res.json({ products: data.products.nodes.map((product) => ({ id: product.id, title: product.title, sku: product.variants.nodes.find((variant) => variant.sku)?.sku || "NO-SKU" })) });
  } catch (error) { res.status(400).json({ error: error.message }); }
});

app.post("/api/upload", upload.array("images"), async (req, res) => {
  try {
    const metadata = JSON.parse(req.body.metadata || "[]");
    if (!req.files?.length || metadata.length !== req.files.length) throw new Error("The upload details did not match the selected images.");
    const results = [];
    for (let index = 0; index < req.files.length; index += 1) {
      const file = req.files[index];
      const meta = metadata[index];
      const staged = await graphql(`mutation Stage($input: [StagedUploadInput!]!) { stagedUploadsCreate(input: $input) { stagedTargets { url resourceUrl parameters { name value } } userErrors { message } } }`, { input: [{ filename: meta.filename, mimeType: file.mimetype, httpMethod: "POST", resource: "PRODUCT_IMAGE" }] });
      const stageErrors = staged.stagedUploadsCreate.userErrors;
      if (stageErrors.length) throw new Error(stageErrors.map((error) => error.message).join("; "));
      const target = staged.stagedUploadsCreate.stagedTargets[0];
      const form = new FormData();
      target.parameters.forEach(({ name, value }) => form.append(name, value));
      form.append("file", new Blob([file.buffer], { type: file.mimetype }), meta.filename);
      const sent = await fetch(target.url, { method: "POST", body: form });
      if (!sent.ok) throw new Error(`Shopify could not receive ${meta.filename}.`);
      const updated = await graphql(`mutation AddMedia($product: ProductUpdateInput!, $media: [CreateMediaInput!]) { productUpdate(product: $product, media: $media) { product { id } userErrors { message } } }`, { product: { id: meta.productId }, media: [{ originalSource: target.resourceUrl, mediaContentType: "IMAGE", alt: meta.alt }] });
      const updateErrors = updated.productUpdate.userErrors;
      if (updateErrors.length) throw new Error(updateErrors.map((error) => error.message).join("; "));
      results.push({ filename: meta.filename, ok: true });
    }
    res.json({ results });
  } catch (error) { res.status(400).json({ error: error.message }); }
});

const vite = await createViteServer({ server: { middlewareMode: true }, appType: "spa" });
app.use(vite.middlewares);
app.listen(3100, "127.0.0.1", () => console.log("Shopify Product Image Manager: http://localhost:3100"));
