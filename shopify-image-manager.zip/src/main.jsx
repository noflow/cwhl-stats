import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

function safeName(value) {
  return value.trim().replace(/[^a-z0-9_-]+/gi, "-").replace(/^-+|-+$/g, "").toUpperCase();
}

async function readJson(response) {
  const contentType = response.headers.get("content-type") || "";
  if (!contentType.includes("application/json")) {
    throw new Error("The secure connector is not running. Close older app windows and start this updated version again.");
  }
  return response.json();
}

function App() {
  const [images, setImages] = useState([]);
  const [products, setProducts] = useState([]);
  const [query, setQuery] = useState("");
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [selectedIds, setSelectedIds] = useState([]);
  const [shop, setShop] = useState(localStorage.getItem("shopDomain") || "");
  const [clientId, setClientId] = useState("");
  const [clientSecret, setClientSecret] = useState("");
  const [connected, setConnected] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");

  const filteredProducts = useMemo(() => {
    const needle = query.toLowerCase().trim();
    return products.filter((product) => !needle || `${product.sku} ${product.title}`.toLowerCase().includes(needle));
  }, [products, query]);

  function addFiles(fileList) {
    const incoming = Array.from(fileList).filter((file) => file.type.startsWith("image/"));
    const next = incoming.map((file, index) => ({
      id: `${file.name}-${file.lastModified}-${index}`,
      file,
      preview: URL.createObjectURL(file),
      product: null,
      alt: "",
    }));
    setImages((current) => [...current, ...next]);
    setNotice(incoming.length ? `${incoming.length} photo${incoming.length === 1 ? "" : "s"} added.` : "Choose JPG, PNG, or other image files.");
  }

  function assignSelected() {
    if (!selectedProduct || !selectedIds.length) return;
    setImages((current) => current.map((image) => selectedIds.includes(image.id)
      ? { ...image, product: selectedProduct, alt: `${selectedProduct.title} product image` }
      : image));
    setNotice(`${selectedIds.length} photo${selectedIds.length === 1 ? "" : "s"} assigned to ${selectedProduct.title}.`);
    setSelectedIds([]);
  }

  function renameFor(image) {
    if (!image.product) return image.file.name;
    const siblings = images.filter((item) => item.product?.id === image.product.id);
    const number = siblings.findIndex((item) => item.id === image.id) + 1;
    const extension = image.file.name.includes(".") ? image.file.name.split(".").pop().toLowerCase() : "jpg";
    return `${safeName(image.product.sku)}-${String(number).padStart(2, "0")}.${extension}`;
  }

  function removeImage(id) {
    setImages((current) => {
      const found = current.find((image) => image.id === id);
      if (found) URL.revokeObjectURL(found.preview);
      return current.filter((image) => image.id !== id);
    });
    setSelectedIds((current) => current.filter((item) => item !== id));
  }

  async function saveConnection() {
    const cleanShop = shop.replace(/^https?:\/\//, "").replace(/\/$/, "");
    setBusy(true);
    try {
      const healthResponse = await fetch("/api/health");
      const health = await readJson(healthResponse);
      if (!healthResponse.ok || health.service !== "shopify-image-manager") throw new Error("The secure connector is not ready.");
      const response = await fetch("/api/connect", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ shop: cleanShop, clientId, clientSecret }) });
      const data = await readJson(response);
      if (!response.ok) throw new Error(data.error);
      localStorage.setItem("shopDomain", cleanShop);
      setShop(cleanShop);
      setClientSecret("");
      const productResponse = await fetch("/api/products");
      const productData = await readJson(productResponse);
      if (!productResponse.ok) throw new Error(productData.error);
      setProducts(productData.products);
      setConnected(true);
      setNotice(`Connected. Loaded ${productData.products.length} products from Shopify.`);
    } catch (error) { setConnected(false); setNotice(error.message); }
    finally { setBusy(false); }
  }

  async function uploadAssigned() {
    const assigned = images.filter((image) => image.product);
    if (!connected) return setNotice("Connect to Shopify first.");
    if (!assigned.length) return setNotice("Assign at least one photo first.");
    setBusy(true);
    try {
      const form = new FormData();
      assigned.forEach((image) => form.append("images", image.file, renameFor(image)));
      form.append("metadata", JSON.stringify(assigned.map((image) => ({ productId: image.product.id, filename: renameFor(image), alt: image.alt }))));
      const response = await fetch("/api/upload", { method: "POST", body: form });
      const data = await readJson(response);
      if (!response.ok) throw new Error(data.error);
      setNotice(`${data.results.length} image${data.results.length === 1 ? "" : "s"} uploaded to Shopify.`);
    } catch (error) { setNotice(error.message); }
    finally { setBusy(false); }
  }

  function exportPlan() {
    const assigned = images.filter((image) => image.product);
    if (!assigned.length) return setNotice("Assign at least one photo before exporting.");
    const rows = [["original_filename", "new_filename", "sku", "product_title", "alt_text"], ...assigned.map((image) => [image.file.name, renameFor(image), image.product.sku, image.product.title, image.alt])];
    const csv = rows.map((row) => row.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(",")).join("\r\n");
    const link = document.createElement("a");
    link.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    link.download = "shopify-image-plan.csv";
    link.click();
    URL.revokeObjectURL(link.href);
    setNotice("Image plan exported.");
  }

  return (
    <main>
      <header className="topbar">
        <div className="brandMark">S</div>
        <div><p className="eyebrow">LOCAL WORKSPACE</p><h1>Product Image Manager</h1></div>
        <div className="status"><span /> Files stay on this computer</div>
      </header>

      <section className="hero">
        <div><p className="eyebrow">A calmer product-photo workflow</p><h2>From camera roll to catalog-ready.</h2><p>Drop in photos, match them to products, and create consistent filenames and alt text before upload.</p></div>
        <div className="heroActions"><button className="secondary" onClick={exportPlan}>Export image plan</button><button onClick={uploadAssigned} disabled={busy}>{busy ? "Working…" : "Upload to Shopify"}</button></div>
      </section>

      <section className="connection panel">
        <div><p className="step">01 · STORE</p><h3>Shopify connection</h3><p>Your secret stays only in the local server's memory and clears when the app closes.</p></div>
        <label>Shop domain<input value={shop} onChange={(event) => setShop(event.target.value)} placeholder="your-store.myshopify.com" /></label>
        <label>Client ID<input value={clientId} onChange={(event) => setClientId(event.target.value)} placeholder="From Dev Dashboard" /></label>
        <label>Client Secret<input type="password" value={clientSecret} onChange={(event) => setClientSecret(event.target.value)} placeholder="Kept in memory only" /></label>
        <button onClick={saveConnection} disabled={busy}>{connected ? "Reconnect" : "Connect"}</button>
      </section>

      <div className="workspace">
        <section className="panel photos">
          <div className="sectionHead"><div><p className="step">02 · PHOTOS</p><h3>Camera files</h3></div><span>{images.length} added</span></div>
          <label className="dropzone" onDragOver={(event) => event.preventDefault()} onDrop={(event) => { event.preventDefault(); addFiles(event.dataTransfer.files); }}>
            <input type="file" accept="image/*" multiple onChange={(event) => addFiles(event.target.files)} />
            <strong>Drop product photos here</strong><span>or click to choose files</span>
          </label>
          <div className="photoGrid">
            {images.map((image) => <article className={`photoCard ${selectedIds.includes(image.id) ? "selected" : ""}`} key={image.id}>
              <button className="thumb" onClick={() => setSelectedIds((current) => current.includes(image.id) ? current.filter((id) => id !== image.id) : [...current, image.id])} aria-label={`Select ${image.file.name}`}><img src={image.preview} alt="" /><span className="check">✓</span></button>
              <div><b>{renameFor(image)}</b><small>{image.product ? image.product.title : "Not assigned"}</small></div>
              <button className="remove" onClick={() => removeImage(image.id)} aria-label={`Remove ${image.file.name}`}>×</button>
            </article>)}
          </div>
        </section>

        <aside className="panel products">
          <p className="step">03 · MATCH</p><h3>Choose a product</h3>
          <input className="search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search SKU or product name" />
          <div className="productList">{filteredProducts.map((product) => <button key={product.id} className={selectedProduct?.id === product.id ? "active" : ""} onClick={() => setSelectedProduct(product)}><span>{product.title}</span><small>{product.sku}</small></button>)}</div>
          <button className="assign" disabled={!selectedProduct || !selectedIds.length} onClick={assignSelected}>Assign {selectedIds.length || "selected"} photo{selectedIds.length === 1 ? "" : "s"}</button>
          <p className="demoNote">{connected ? `${products.length} live products loaded.` : "Connect your store to load live products."}</p>
        </aside>
      </div>
      {notice && <div className="toast" role="status">{notice}<button onClick={() => setNotice("")}>×</button></div>}
    </main>
  );
}

createRoot(document.getElementById("root")).render(<App />);
